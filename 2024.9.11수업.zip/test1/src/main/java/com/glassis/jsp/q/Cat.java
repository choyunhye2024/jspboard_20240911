package com.glassis.jsp.q;

public class Cat {

	public String name = "고양이";

}
